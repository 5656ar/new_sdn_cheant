import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Age & BMI Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AgeBMIProfile(),
    );
  }
}

class AgeBMIProfile extends StatefulWidget {
  @override
  _AgeBMIProfileState createState() => _AgeBMIProfileState();
}

class _AgeBMIProfileState extends State<AgeBMIProfile> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();

  late Database _database;

  @override
  void initState() {
    super.initState();
    _initDatabase();
  }

  Future<void> _initDatabase() async {
    _database = await openDatabase(
      join(await getDatabasesPath(), 'profile_database.db'),
      onCreate: (db, version) {
        return db.execute(
          "CREATE TABLE profiles(id INTEGER PRIMARY KEY, name TEXT, age INTEGER, weight REAL, height INTEGER)",
        );
      },
      version: 1,
    );
  }

  Future<void> _addProfile() async {
    await _database.insert(
      'profiles',
      {
        'name': _nameController.text,
        'age': int.parse(_ageController.text),
        'weight': double.parse(_weightController.text),
        'height': int.parse(_heightController.text),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    setState(() {
      _nameController.text = '';
      _ageController.text = '';
      _weightController.text = '';
      _heightController.text = '';
    });
  }

  Future<void> _deleteProfile(int id) async {
    await _database.delete(
      'profiles',
      where: "id = ?",
      whereArgs: [id],
    );
    setState(() {});
  }

  double _calculateBMI(double weight, double height) {
    return weight / ((height / 100) * (height / 100));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Age & BMI Calculator'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Name',
              ),
            ),
            // input text
            TextField(
              controller: _ageController,
              decoration: InputDecoration(labelText: 'Age'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _weightController,
              decoration: InputDecoration(labelText: 'Weight (kg)'),
              keyboardType: TextInputType.numberWithOptions(decimal: true),
            ),
            TextField(
              controller: _heightController,
              decoration: InputDecoration(labelText: 'Height (cm)'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _addProfile,
              child: Text('Add Profile'),
            ),
            SizedBox(height: 16.0),

            /// end input text
            Expanded(
              child: FutureBuilder<void>(
                future: _initDatabase(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState != ConnectionState.done) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  return FutureBuilder<List<Map<String, dynamic>>>(
                    future: _database.query('profiles'),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      }

                      return ListView.builder(
                        itemCount: snapshot.data!.length,
                        itemBuilder: (context, index) {
                          final profile = snapshot.data![index];
                          final double bmi = _calculateBMI(
                              profile['weight'], profile['height']);
                          return ListTile(
                            title: Text(profile['name']),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Age: ${profile['age']}'),
                                Text('Weight: ${profile['weight']} kg'),
                                Text('Height: ${profile['height']} cm'),
                                Text('BMI: ${bmi.toStringAsFixed(2)}'),
                              ],
                            ),
                            trailing: IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () {
                                _deleteProfile(profile['id']);
                              },
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
