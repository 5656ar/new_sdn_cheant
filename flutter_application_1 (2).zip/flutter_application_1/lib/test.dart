import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Age Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: AgeCalculator(),
    );
  }
}

class AgeCalculator extends StatefulWidget {
  @override
  _AgeCalculatorState createState() => _AgeCalculatorState();
}

class _AgeCalculatorState extends State<AgeCalculator> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();

  late Database _database;

  @override
  void initState() {
    super.initState();
    _initDatabase();
  }

  Future<void> _initDatabase() async {
    _database = await openDatabase(
      join(await getDatabasesPath(), 'profile_database.db'),
      onCreate: (db, version) {
        return db.execute(
          "CREATE TABLE profiles(id INTEGER PRIMARY KEY, name TEXT, age INTEGER)",
        );
      },
      version: 1,
    );
  }

  Future<void> _addProfile() async {
    await _database.insert(
      'profiles',
      {
        'name': _nameController.text,
        'age': int.parse(_ageController.text),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    setState(() {
      _nameController.text = '';
      _ageController.text = '';
    });
  }

  Future<void> _updateProfile(int id) async {
    await _database.update(
      'profiles',
      {
        'name': _nameController.text,
        'age': int.parse(_ageController.text),
      },
      where: "id = ?",
      whereArgs: [id],
    );
    setState(() {
      _nameController.text = '';
      _ageController.text = '';
    });
  }

  Future<void> _deleteProfile(int id) async {
    await _database.delete(
      'profiles',
      where: "id = ?",
      whereArgs: [id],
    );
  }

  Future<void> _editProfile(
      int id, String name, int age, BuildContext context) async {
    _nameController.text = name;
    _ageController.text = age.toString();

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('Edit Profile'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                ),
              ),
              TextField(
                controller: _ageController,
                decoration: InputDecoration(
                  labelText: 'Age',
                ),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                await _updateProfile(id);
                Navigator.of(dialogContext).pop();
              },
              child: Text('Update'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Age Calculator'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Name',
              ),
            ),
            TextField(
              controller: _ageController,
              decoration: InputDecoration(
                labelText: 'Age',
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed:
                  _nameController.text.isEmpty || _ageController.text.isEmpty
                      ? null
                      : () {
                          if (_nameController.text.isNotEmpty &&
                              _ageController.text.isNotEmpty) {
                            _addProfile();
                          }
                        },
              child: Text('Add Profile'),
            ),
            SizedBox(height: 16.0),
            Expanded(
              child: FutureBuilder<void>(
                future: _initDatabase(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState != ConnectionState.done) {
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  }

                  return FutureBuilder<List<Map<String, dynamic>>>(
                    future: _database.query('profiles'),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return Center(
                          child: CircularProgressIndicator(),
                        );
                      }

                      return ListView.builder(
                        itemCount: snapshot.data!.length,
                        itemBuilder: (context, index) {
                          final profile = snapshot.data![index];
                          return ListTile(
                            title: Text(profile['name']),
                            subtitle: Text('Age: ${profile['age']}'),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: Icon(Icons.edit),
                                  onPressed: () {
                                    _editProfile(profile['id'], profile['name'],
                                        profile['age'], context);
                                  },
                                ),
                                IconButton(
                                  icon: Icon(Icons.delete),
                                  onPressed: () {
                                    _deleteProfile(profile['id']);
                                    setState(() {});
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
