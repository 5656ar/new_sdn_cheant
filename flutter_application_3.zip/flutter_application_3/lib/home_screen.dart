import 'package:flutter/material.dart';
import 'package:flutter_application_6/screens/simple_map_screen.dart';
import 'package:flutter_application_6/screens/gotohome.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        brightness: Brightness.dark, // ตั้งค่าธีมเป็น dark
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.black, // สีพื้นหลังของ AppBar
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
            textStyle: TextStyle(fontSize: 20), // ขนาดตัวอักษร
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20), // รูปร่างของปุ่ม
            ),
          ),
        ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Google Map New"),
          centerTitle: true,
          elevation: 0, // ไม่มีเงาใต้ AppBar
        ),
        body: SizedBox(
          width: MediaQuery.of(context).size.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) {
                      return MapSample();
                    }),
                  );
                },
                child: const Text("Simple Map"),
              ),
              const SizedBox(height: 20), // ระยะห่างระหว่างปุ่ม
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (BuildContext context) {
                      return MapHome();
                    }),
                  );
                },
                child: const Text("Home Map"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
