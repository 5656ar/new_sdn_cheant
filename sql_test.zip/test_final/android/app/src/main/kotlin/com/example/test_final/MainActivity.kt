package com.example.test_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
